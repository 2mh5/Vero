const {
  Client,
  GatewayIntentBits,
  Partials,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
  PermissionsBitField,
} = require("discord.js");
const fs = require("node:fs");
const path = require("node:path");

const TOKEN = process.env.DISCORD_TOKEN;
const OWNER_ID = process.env.OWNER_ID;
if (!TOKEN || !OWNER_ID) {
  console.error("خطأ إعداد: أضف DISCORD_TOKEN و OWNER_ID إلى Replit Secrets.");
  process.exit(1);
}

const DATA_DIR = path.join(__dirname, "..", "data");
const STORE_PATH = path.join(DATA_DIR, "store.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

const defaultStore = {
  guilds: {},
  logs: []
};
let store;
try {
  store = fs.existsSync(STORE_PATH)
    ? { ...defaultStore, ...JSON.parse(fs.readFileSync(STORE_PATH, "utf8")) }
    : structuredClone(defaultStore);
} catch (error) {
  console.error("تعذرت قراءة data/store.json. أصلح الملف أو احذفه لإنشاء إعدادات جديدة.", error);
  process.exit(1);
}

function saveStore() {
  fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), "utf8");
}
function guildConfig(guildId) {
  if (!store.guilds[guildId]) {
    store.guilds[guildId] = {
      prefix: process.env.DEFAULT_PREFIX || "!",
      accessMode: true,
      allowedUsers: [],
      allowedRoles: []
    };
    saveStore();
  }
  return store.guilds[guildId];
}
function hasAccess(member, userId, config) {
  if (userId === OWNER_ID) return true;
  if (config.accessMode) {
    return config.allowedUsers.includes(userId) ||
      member.roles.cache.some(role => config.allowedRoles.includes(role.id));
  }
  return Boolean(member.permissions.has(PermissionsBitField.Flags.ManageGuild));
}
function isOwner(userId) {
  return userId === OWNER_ID;
}
function clampText(value, max) {
  return String(value || "").slice(0, max);
}
function safeUrl(value) {
  if (!value) return null;
  try {
    const u = new URL(value);
    return ["https:", "http:"].includes(u.protocol) ? u.toString() : null;
  } catch {
    return null;
  }
}
function chunkIds(value) {
  return [...new Set(String(value || "").split(/[,\s]+/).map(x => x.trim()).filter(x => /^\d{15,22}$/.test(x)))];
}
function panelRows(session) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`bc:compose:${session.id}`).setLabel("Compose").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`bc:recipients:${session.id}`).setLabel("Recipients").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`bc:preview:${session.id}`).setLabel("Preview").setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`bc:send:${session.id}`).setLabel("Send").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`bc:cancel:${session.id}`).setLabel("Cancel").setStyle(ButtonStyle.Danger),
    )
  ];
}
function panelEmbed(session) {
  const audience = session.audience.type === "everyone" ? "Everyone" :
    session.audience.type === "role" ? `Role ID: ${session.audience.roleId || "not set"}` :
    `Selected members: ${session.audience.userIds.length}`;
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle("لوحة الإعلانات الخاصة")
    .setDescription("جهّز الرسالة وحدّد الجمهور، ثم عاينها قبل الإرسال.")
    .addFields(
      { name: "Content", value: session.content.title ? "Configured" : "Not configured", inline: true },
      { name: "Format", value: session.content.mode === "text" ? "Plain text" : "Embed", inline: true },
      { name: "Recipients", value: audience, inline: true },
    )
    .setFooter({ text: "الإرسال يكون عبر الخاص، وقد ترفض Discord بعض الرسائل." });
}
function makePreview(session) {
  if (session.content.mode === "text") {
    let text = session.content.body || "(لا يوجد نص بعد)";
    if (session.content.title) text = `**${session.content.title}**\n${text}`;
    if (session.content.imageUrl) text += `\n${session.content.imageUrl}`;
    return { content: text.slice(0, 2000), embeds: [] };
  }
  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle(session.content.title || "إعلان")
    .setDescription(session.content.body || "لا يوجد نص بعد");
  if (session.content.imageUrl) embed.setImage(session.content.imageUrl);
  return { content: null, embeds: [embed] };
}
function createSession(guildId, userId) {
  const id = Math.random().toString(36).slice(2, 9);
  const session = {
    id, guildId, userId, createdAt: Date.now(),
    content: { title: "", body: "", imageUrl: "", mode: "embed" },
    audience: { type: "everyone", roleId: "", userIds: [] },
    cancelled: false, running: false
  };
  sessions.set(id, session);
  return session;
}
const sessions = new Map();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel, Partials.Message, Partials.GuildMember, Partials.User]
});

client.once("ready", () => {
  console.log(`تم تسجيل الدخول بنجاح باسم ${client.user.tag}`);
  console.log("الأوامر تعمل بالبادئة فقط. اكتب !help (أو البادئة التي ضبطتها).");
});

async function fetchRecipients(guild, audience) {
  if (audience.type === "everyone") {
    await guild.members.fetch();
    return [...guild.members.cache.values()].filter(m => !m.user.bot);
  }
  if (audience.type === "role") {
    if (!/^\d{15,22}$/.test(audience.roleId)) throw new Error("رقم الرتبة غير صحيح.");
    const role = await guild.roles.fetch(audience.roleId).catch(() => null);
    if (!role) throw new Error("لم أجد هذه الرتبة في السيرفر.");
    await guild.members.fetch();
    return [...role.members.values()].filter(m => !m.user.bot);
  }
  const members = [];
  for (const id of audience.userIds) {
    const member = await guild.members.fetch(id).catch(() => null);
    if (member && !member.user.bot) members.push(member);
  }
  return [...new Map(members.map(m => [m.id, m])).values()];
}

async function runBroadcast(interaction, session) {
  if (session.running) {
    return interaction.reply({ content: "هذه الحملة قيد التنفيذ بالفعل.", ephemeral: true });
  }
  if (!session.content.body.trim()) {
    return interaction.reply({ content: "أضف نص الرسالة أولاً باستخدام Compose.", ephemeral: true });
  }
  if (session.audience.type === "role" && !session.audience.roleId) {
    return interaction.reply({ content: "حدّد رقم الرتبة من Recipients أولاً.", ephemeral: true });
  }
  if (session.audience.type === "members" && session.audience.userIds.length === 0) {
    return interaction.reply({ content: "أضف أرقام الأعضاء من Recipients أولاً.", ephemeral: true });
  }
  session.running = true;
  await interaction.reply({
    content: "بدأت الحملة. يمكنك متابعة التقدم أو إيقاف الإرسال من الزر أدناه.",
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`bc:cancel:${session.id}`).setLabel("Cancel Campaign").setStyle(ButtonStyle.Danger)
    )],
    ephemeral: true
  });
  let progressMessage = await interaction.fetchReply().catch(() => null);

  let recipients;
  try {
    recipients = await fetchRecipients(interaction.guild, session.audience);
  } catch (error) {
    session.running = false;
    return interaction.followUp({ content: `تعذر تجهيز المستلمين: ${error.message}`, ephemeral: true });
  }

  let sent = 0, failed = 0, skipped = 0;
  const failureExamples = [];
  const startedAt = new Date().toISOString();
  const payload = makePreview(session);
  const updateProgress = async () => {
    if (!progressMessage) return;
    const progressEmbed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle(session.cancelled ? "جارٍ إيقاف الحملة..." : "تقدم الحملة")
      .setDescription(`المستلمون: ${recipients.length}\nتم الإرسال: ${sent}\nفشل الإرسال: ${failed}\nتم تخطيهم: ${skipped}`);
    await progressMessage.edit({ embeds: [progressEmbed], content: null }).catch(() => {});
  };

  await updateProgress();
  for (const member of recipients) {
    if (session.cancelled) {
      skipped += recipients.length - sent - failed - skipped;
      break;
    }
    try {
      // لا يتم فحص إعدادات الخصوصية مسبقاً؛ نجرب عبر واجهة Discord الرسمية.
      // Discord.js يتولى تنظيم طلبات API واحترام حدودها.
      await member.send(payload);
      sent++;
    } catch (error) {
      failed++;
      if (failureExamples.length < 8) {
        failureExamples.push(`${member.user.tag} (${member.id}): ${String(error.message || "تعذر الإرسال").slice(0, 100)}`);
      }
    }
    // فاصل محافظ بين الرسائل لتخفيف الاندفاع؛ لا يتجاوز حدود Discord ولا يحاول الالتفاف عليها.
    if ((sent + failed) % 5 === 0) await updateProgress();
    await new Promise(resolve => setTimeout(resolve, 1200));
  }
  await updateProgress();

  session.running = false;
  const log = {
    id: `${Date.now()}`,
    guildId: interaction.guildId,
    initiatedBy: interaction.user.id,
    startedAt,
    completedAt: new Date().toISOString(),
    audience: session.audience.type,
    attempted: sent + failed,
    sent, failed, skipped,
    cancelled: session.cancelled
  };
  store.logs.push(log);
  if (store.logs.length > 200) store.logs = store.logs.slice(-200);
  saveStore();

  const report = new EmbedBuilder()
    .setColor(session.cancelled ? 0xFAA61A : 0x57F287)
    .setTitle(session.cancelled ? "تقرير الحملة (تم الإلغاء)" : "تقرير الحملة")
    .addFields(
      { name: "المستلمون المحددون", value: String(recipients.length), inline: true },
      { name: "تم الإرسال", value: String(sent), inline: true },
      { name: "فشل الإرسال", value: String(failed), inline: true },
      { name: "تم تخطيهم", value: String(skipped), inline: true }
    );
  if (failureExamples.length) {
    report.addFields({ name: "نماذج من حالات الفشل", value: failureExamples.join("\n").slice(0, 1024) });
  }
  report.setFooter({ text: "فشل DM لا يعني بالضرورة أن الحساب غير موجود؛ قد تكون الخصوصية أو قيود Discord هي السبب." });
  await interaction.followUp({ embeds: [report], ephemeral: true });
  sessions.delete(session.id);
}

client.on("messageCreate", async message => {
  if (!message.guild || message.author.bot) return;
  const config = guildConfig(message.guild.id);
  const prefix = config.prefix || "!";
  if (!message.content.startsWith(prefix)) return;

  const raw = message.content.slice(prefix.length).trim();
  const parts = raw.split(/\s+/);
  const command = (parts.shift() || "").toLowerCase();
  const args = parts;

  if (command === "help") {
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle("مساعدة بوت الإعلانات")
      .setDescription([
        `\`${prefix}broadcast\` — فتح لوحة الإعلانات`,
        `\`${prefix}setprefix ?\` — تغيير البادئة`,
        `\`${prefix}access user add USER_ID\` — السماح لمستخدم`,
        `\`${prefix}access user remove USER_ID\` — إزالة مستخدم`,
        `\`${prefix}access role add ROLE_ID\` — السماح لرتبة`,
        `\`${prefix}access role remove ROLE_ID\` — إزالة رتبة`,
        `\`${prefix}access list\` — عرض السماح`,
        `\`${prefix}access mode on/off\` — تشغيل/إيقاف قائمة السماح`
      ].join("\n"));
    return message.reply({ embeds: [embed] });
  }

  if (command === "setprefix") {
    if (!isOwner(message.author.id) && !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return message.reply("هذا الأمر للمالك أو لمن لديه صلاحية Manage Server.");
    }
    const next = args[0];
    if (!next || next.length > 5 || /\s/.test(next)) {
      return message.reply(`استخدم: \`${prefix}setprefix ?\` (بادئة من 1 إلى 5 أحرف دون مسافات).`);
    }
    config.prefix = next;
    saveStore();
    return message.reply(`تم تغيير البادئة إلى \`${next}\`.`);
  }

  if (command === "access") {
    if (!isOwner(message.author.id)) return message.reply("هذا الأمر متاح لمالك البوت فقط.");
    const [kind, action, id] = args;
    if (kind === "mode" && ["on", "off"].includes(action)) {
      config.accessMode = action === "on";
      saveStore();
      return message.reply(config.accessMode
        ? "تم تفعيل قائمة السماح. المالك مسموح دائماً."
        : "تم إيقاف قائمة السماح. المالك وأصحاب Manage Server يستطيعون استخدام لوحة الإعلانات.");
    }
    if (kind === "list") {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle("قائمة السماح")
          .addFields(
            { name: "Users", value: config.allowedUsers.join("\n") || "لا يوجد", inline: true },
            { name: "Roles", value: config.allowedRoles.join("\n") || "لا يوجد", inline: true },
            { name: "Mode", value: config.accessMode ? "On" : "Off", inline: true }
          )]
      });
    }
    if (!["user", "role"].includes(kind) || !["add", "remove"].includes(action) || !/^\d{15,22}$/.test(id || "")) {
      return message.reply(`الاستخدام:\n\`${prefix}access user add USER_ID\`\n\`${prefix}access user remove USER_ID\`\n\`${prefix}access role add ROLE_ID\`\n\`${prefix}access role remove ROLE_ID\`\n\`${prefix}access list\`\n\`${prefix}access mode on/off\``);
    }
    const list = kind === "user" ? config.allowedUsers : config.allowedRoles;
    if (action === "add" && !list.includes(id)) list.push(id);
    if (action === "remove") {
      const index = list.indexOf(id);
      if (index >= 0) list.splice(index, 1);
    }
    saveStore();
    return message.reply(`${action === "add" ? "تمت الإضافة إلى" : "تمت الإزالة من"} قائمة ${kind === "user" ? "المستخدمين" : "الرتب"}.`);
  }

  if (command === "broadcast") {
    if (!hasAccess(message.member, message.author.id, config)) {
      return message.reply("ليس لديك صلاحية استخدام لوحة الإعلانات.");
    }
    const session = createSession(message.guild.id, message.author.id);
    return message.reply({ embeds: [panelEmbed(session)], components: panelRows(session) });
  }
});

client.on("interactionCreate", async interaction => {
  if (!interaction.inGuild() || !interaction.guild) return;
  const customId = interaction.customId || "";
  if (!customId.startsWith("bc:")) return;
  const [, action, sessionId] = customId.split(":");
  const session = sessions.get(sessionId);
  if (!session || session.guildId !== interaction.guildId) {
    return interaction.reply({ content: "انتهت صلاحية هذه اللوحة. نفّذ أمر broadcast من جديد.", ephemeral: true });
  }
  if (session.userId !== interaction.user.id && interaction.user.id !== OWNER_ID) {
    return interaction.reply({ content: "هذه اللوحة تخص مستخدماً آخر.", ephemeral: true });
  }
  if (session.cancelled) return interaction.reply({ content: "تم إلغاء هذه المسودة.", ephemeral: true });

  if (action === "compose") {
    const modal = new ModalBuilder().setCustomId(`bcmodal:compose:${session.id}`).setTitle("Compose broadcast");
    const title = new TextInputBuilder().setCustomId("title").setLabel("العنوان (اختياري)").setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(256).setValue(session.content.title || "");
    const body = new TextInputBuilder().setCustomId("body").setLabel("نص الرسالة").setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(4000).setValue(session.content.body || "");
    const image = new TextInputBuilder().setCustomId("image").setLabel("رابط صورة HTTP/HTTPS (اختياري)").setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(session.content.imageUrl || "");
    const mode = new TextInputBuilder().setCustomId("mode").setLabel("النوع: embed أو text").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(10).setValue(session.content.mode || "embed");
    modal.addComponents(
      new ActionRowBuilder().addComponents(title),
      new ActionRowBuilder().addComponents(body),
      new ActionRowBuilder().addComponents(image),
      new ActionRowBuilder().addComponents(mode)
    );
    return interaction.showModal(modal);
  }

  if (action === "recipients") {
    const menu = new StringSelectMenuBuilder()
      .setCustomId(`bc:audience:${session.id}`)
      .setPlaceholder("اختر الجمهور")
      .addOptions(
        { label: "Everyone", description: "كل الأعضاء غير البوتات", value: "everyone" },
        { label: "Role", description: "أعضاء رتبة محددة", value: "role" },
        { label: "Selected members", description: "حسابات محددة بأرقام المستخدمين", value: "members" }
      );
    return interaction.reply({
      content: `الجمهور الحالي: ${session.audience.type}. بعد الاختيار ستظهر لك نافذة لإدخال رقم الرتبة أو أرقام المستخدمين عند الحاجة.`,
      components: [new ActionRowBuilder().addComponents(menu)],
      ephemeral: true
    });
  }

  if (action === "audience" && interaction.isStringSelectMenu()) {
    const choice = interaction.values[0];
    if (choice === "everyone") {
      session.audience = { type: "everyone", roleId: "", userIds: [] };
      return interaction.update({ content: "تم اختيار Everyone.", components: [] });
    }
    const modal = new ModalBuilder()
      .setCustomId(`bcmodal:audience:${session.id}:${choice}`)
      .setTitle(choice === "role" ? "Select role" : "Select members");
    const input = new TextInputBuilder()
      .setCustomId("ids")
      .setLabel(choice === "role" ? "رقم الرتبة (Role ID)" : "أرقام المستخدمين مفصولة بفواصل")
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(1800)
      .setPlaceholder(choice === "role" ? "123456789012345678" : "123456789012345678, 234567890123456789");
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (action === "preview") {
    const preview = makePreview(session);
    return interaction.reply({
      content: "معاينة الرسالة (لن يتم الإرسال عند المعاينة):",
      ...(preview.content ? { content: `معاينة الرسالة:\n${preview.content}` } : {}),
      embeds: preview.embeds,
      ephemeral: true
    });
  }

  if (action === "send") {
    if (session.running) return interaction.reply({ content: "الحملة قيد التنفيذ بالفعل.", ephemeral: true });
    const confirm = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`bc:confirm:${session.id}`).setLabel("Confirm Send").setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(`bc:cancel:${session.id}`).setLabel("Cancel").setStyle(ButtonStyle.Secondary)
    );
    return interaction.reply({
      content: "هل أنت متأكد من بدء الإرسال إلى الجمهور المحدد؟ لا يمكن استرجاع الرسائل التي وصلت بالفعل.",
      components: [confirm],
      ephemeral: true
    });
  }

  if (action === "confirm") {
    return runBroadcast(interaction, session);
  }

  if (action === "cancel") {
    session.cancelled = true;
    if (!session.running) sessions.delete(session.id);
    return interaction.update({ content: "تم إلغاء المسودة أو طلب إيقاف الحملة.", components: [], embeds: [] }).catch(() =>
      interaction.reply({ content: "تم إلغاء المسودة أو طلب إيقاف الحملة.", ephemeral: true })
    );
  }
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isModalSubmit()) return;
  const parts = interaction.customId.split(":");
  if (parts[0] !== "bcmodal") return;
  const [, kind, sessionId, audienceType] = parts;
  const session = sessions.get(sessionId);
  if (!session || session.guildId !== interaction.guildId || (session.userId !== interaction.user.id && interaction.user.id !== OWNER_ID)) {
    return interaction.reply({ content: "انتهت صلاحية هذه اللوحة أو ليست لك.", ephemeral: true });
  }
  if (kind === "compose") {
    const mode = interaction.fields.getTextInputValue("mode").trim().toLowerCase();
    if (!["embed", "text"].includes(mode)) {
      return interaction.reply({ content: "اكتب النوع كـ embed أو text.", ephemeral: true });
    }
    const rawImage = interaction.fields.getTextInputValue("image").trim();
    const imageUrl = rawImage ? safeUrl(rawImage) : null;
    if (rawImage && !imageUrl) return interaction.reply({ content: "رابط الصورة غير صالح. استخدم رابط HTTP أو HTTPS.", ephemeral: true });
    session.content = {
      title: clampText(interaction.fields.getTextInputValue("title").trim(), 256),
      body: clampText(interaction.fields.getTextInputValue("body").trim(), 4000),
      imageUrl: imageUrl || "",
      mode
    };
    return interaction.reply({ content: "تم حفظ محتوى الرسالة. اضغط Preview لمراجعتها.", ephemeral: true });
  }
  if (kind === "audience") {
    const raw = interaction.fields.getTextInputValue("ids").trim();
    if (audienceType === "role") {
      if (!/^\d{15,22}$/.test(raw)) return interaction.reply({ content: "رقم الرتبة غير صحيح.", ephemeral: true });
      session.audience = { type: "role", roleId: raw, userIds: [] };
      return interaction.reply({ content: "تم حفظ الرتبة. راجع لوحة التحكم ثم Preview وSend.", ephemeral: true });
    }
    const ids = chunkIds(raw);
    if (!ids.length) return interaction.reply({ content: "لم أجد أرقام مستخدمين صحيحة. استخدم User IDs مفصولة بفواصل.", ephemeral: true });
    if (ids.length > 100) return interaction.reply({ content: "الحد الأقصى في الاختيار اليدوي هو 100 مستخدم في كل حملة.", ephemeral: true });
    session.audience = { type: "members", roleId: "", userIds: ids };
    return interaction.reply({ content: `تم حفظ ${ids.length} مستخدم/مستخدمين ضمن الجمهور.`, ephemeral: true });
  }
});

client.on("error", error => console.error("Discord client error:", error));
process.on("unhandledRejection", error => console.error("Unhandled rejection:", error));

client.login(TOKEN);
